import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const vendor=path.join(root,'app','src','main','assets','www','vendor');
fs.mkdirSync(vendor,{recursive:true});
const src=path.join(root,'node_modules','js-synthesizer');
if(!fs.existsSync(src))throw Error('Missing node_modules: run npm install first, then build APK.');
const srcExternal=path.join(src,'externals');
// Emscripten may ship .wasm files separately in some builds. Always include all matching assets.
const fluids=fs.readdirSync(srcExternal).filter(n=>/^libfluidsynth-2\.4\.6\.(js|wasm|data)$/.test(n));
if(!fluids.includes('libfluidsynth-2.4.6.js'))throw Error('FluidSynth JS missing from installed npm package');
for(const filename of fluids)fs.copyFileSync(path.join(srcExternal,filename),path.join(vendor,filename));
for(const [from,to] of [
  [path.join(src,'dist','js-synthesizer.min.js'),'js-synthesizer.min.js'],
  [path.join(root,'node_modules','jszip','dist','jszip.min.js'),'jszip.min.js'],
  [path.join(src,'LICENSE'),'JS-SYNTHESIZER-LICENSE.txt'],
  [path.join(srcExternal,'README.md'),'FLUIDSYNTH-LICENSE-NOTES.txt'],
  [path.join(root,'node_modules','jszip','LICENSE.markdown'),'JSZIP-LICENSE.md']
]){
  if(!fs.existsSync(from)){if(/LICENSE/.test(to))continue;throw Error('Missing '+from);}
  fs.copyFileSync(from,path.join(vendor,to));
}
console.log('APK offline assets bundled:',fs.readdirSync(vendor).join(', '));
