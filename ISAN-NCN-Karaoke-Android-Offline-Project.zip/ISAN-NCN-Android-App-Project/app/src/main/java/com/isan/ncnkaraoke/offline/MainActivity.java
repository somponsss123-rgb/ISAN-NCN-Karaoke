package com.isan.ncnkaraoke.offline;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Offline wrapper around the user-tested web synthesizer.
 * The real files stay in the user-selected folders; this app persists READ URI permissions.
 * No INTERNET permission is declared: all runtime scripts must be packaged in APK assets.
 */
public class MainActivity extends Activity {
    private static final int PICK_SONG_TREE = 701;
    private static final int PICK_SF2 = 702;
    private static final int PICK_WEB_FILES = 703;
    private static final String PREF = "saved_user_music_sources";
    private static final String KEY_TREE = "tree_uri";
    private static final String KEY_SF2 = "sf2_uris";
    private static final String ORIGIN = "https://appassets.androidplatform.net";
    private static final int MAX_NCN_FILES = 100000;
    private WebView webView;
    private SharedPreferences preferences;
    private WebViewAssetLoader loader;
    private ValueCallback<Uri[]> webFileCallback;
    private final ConcurrentHashMap<String, Uri> fileUris = new ConcurrentHashMap<>();

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferences = getSharedPreferences(PREF, MODE_PRIVATE);
        webView = new WebView(this);
        webView.setBackgroundColor(0xff0b1425);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setBuiltInZoomControls(false);
        webView.addJavascriptInterface(new UserFileBridge(), "AndroidNCN");
        loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/files/", path -> {
                    Uri uri = fileUris.get(path);
                    if (uri == null) return null;
                    try {
                        InputStream stream = getContentResolver().openInputStream(uri);
                        if (stream == null) return null;
                        return new WebResourceResponse("application/octet-stream", null, stream);
                    } catch (Exception e) {
                        return null;
                    }
                }).build();
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                return loader.shouldInterceptRequest(req.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                return !ORIGIN.equals(req.getUrl().getScheme() + "://" + req.getUrl().getHost());
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (url.startsWith(ORIGIN)) restoreSavedFiles();
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (webFileCallback != null) webFileCallback.onReceiveValue(null);
                webFileCallback = cb;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, PICK_WEB_FILES);
                    return true;
                } catch (Exception ex) {
                    webFileCallback = null;
                    cb.onReceiveValue(null);
                    notice("เปิดตัวเลือกไฟล์ไม่ได้: " + ex.getMessage());
                    return false;
                }
            }
            @Override public void onReceivedTitle(WebView view, String title) { /* Keep the app title. */ }
        });
        webView.loadUrl(ORIGIN + "/assets/www/index.html");
    }

    private final class UserFileBridge {
        @JavascriptInterface public void chooseMusicFolder() {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    startActivityForResult(intent, PICK_SONG_TREE);
                } catch (Exception e) { notice("เลือกโฟลเดอร์ไม่ได้: " + e.getMessage()); }
            });
        }
        @JavascriptInterface public void chooseSF2() {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    startActivityForResult(intent, PICK_SF2);
                } catch (Exception e) { notice("เลือก SF2 ไม่ได้: " + e.getMessage()); }
            });
        }
        @JavascriptInterface public void clearMusicFolder() {
            preferences.edit().remove(KEY_TREE).apply();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_WEB_FILES) {
            ValueCallback<Uri[]> cb = webFileCallback;
            webFileCallback = null;
            if (cb != null) cb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            return;
        }
        if (resultCode != RESULT_OK || data == null) return;
        if (requestCode == PICK_SONG_TREE) {
            Uri uri = data.getData();
            if (uri == null) return;
            if (!keepReadPermission(uri)) return;
            preferences.edit().putString(KEY_TREE, uri.toString()).apply();
            scanMusic(uri);
        } else if (requestCode == PICK_SF2) {
            List<String> urls = loadSavedSF2Uris();
            if (data.getData() != null) addSF2Uri(data.getData(), urls);
            ClipData clip = data.getClipData();
            if (clip != null) for (int i=0; i<clip.getItemCount(); i++) addSF2Uri(clip.getItemAt(i).getUri(), urls);
            JSONArray json = new JSONArray();
            for (String s : urls) json.put(s);
            preferences.edit().putString(KEY_SF2, json.toString()).apply();
            emitSF2List();
        }
    }

    private boolean keepReadPermission(Uri uri) {
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            return true;
        } catch (SecurityException e) {
            notice("ไม่สามารถบันทึกสิทธิ์อ่านไฟล์ถาวร: " + e.getMessage());
            return false;
        }
    }
    private void addSF2Uri(Uri uri, List<String> urls) {
        if (uri == null || !keepReadPermission(uri)) return;
        String filename = readableName(uri);
        if (!filename.toLowerCase(java.util.Locale.ROOT).endsWith(".sf2")) {
            notice("ข้ามไฟล์ที่ไม่ใช่ SF2: " + filename);
            return;
        }
        if (!urls.contains(uri.toString()) && urls.size() < 5) urls.add(uri.toString());
    }
    private List<String> loadSavedSF2Uris() {
        ArrayList<String> result = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(preferences.getString(KEY_SF2, "[]"));
            for (int i=0; i<arr.length(); i++) result.add(arr.getString(i));
        } catch (JSONException ignored) {}
        return result;
    }
    private void restoreSavedFiles() {
        String savedTree = preferences.getString(KEY_TREE, "");
        emitSF2List();
        if (!savedTree.isEmpty()) scanMusic(Uri.parse(savedTree));
        else notice("เลือกโฟลเดอร์ NCN และไฟล์ SoundFont หนึ่งครั้งเพื่อให้แอปจำไว้");
    }
    private JSONObject fileMeta(Uri uri, String name, String path, long size) throws JSONException {
        String id = UUID.randomUUID().toString();
        fileUris.put(id, uri);
        JSONObject obj = new JSONObject();
        obj.put("id", id); obj.put("name", name); obj.put("path", path); obj.put("size", size);
        return obj;
    }
    private void emitSF2List() {
        new Thread(() -> {
            try {
                JSONArray array = new JSONArray();
                for (String encoded : loadSavedSF2Uris()) {
                    Uri uri = Uri.parse(encoded);
                    array.put(fileMeta(uri, readableName(uri), readableName(uri), readableSize(uri)));
                }
                js("window.isanNativeSF2List(" + array + ")");
            } catch (Exception e) { notice("คืนค่า SF2 ไม่สำเร็จ: " + e.getMessage()); }
        }, "restore-sf2").start();
    }
    private void scanMusic(Uri treeUri) {
        new Thread(() -> {
            try {
                js("window.isanNativeMusicStart()");
                JSONArray batch = new JSONArray();
                int[] count = {0};
                String rootDocId = DocumentsContract.getTreeDocumentId(treeUri);
                walkTree(treeUri, rootDocId, "", 0, count, batch);
                if (batch.length() > 0) emitBatch(batch);
                js("window.isanNativeMusicEnd()");
            } catch (Exception e) {
                notice("ไม่สามารถอ่านโฟลเดอร์เดิมได้: " + e.getMessage());
                js("window.isanNativeMusicEnd()");
            }
        }, "scan-ncn-folder").start();
    }
    private void emitBatch(JSONArray batch) {
        js("window.isanNativeMusicBatch(" + batch.toString() + ")");
    }
    private void walkTree(Uri treeUri, String docId, String folder, int depth, int[] count, JSONArray batch) throws Exception {
        if (depth > 18 || count[0] >= MAX_NCN_FILES) return;
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId);
        String[] cols = { DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE };
        try (Cursor c = getContentResolver().query(children, cols, null, null, null)) {
            if (c == null) return;
            while (c.moveToNext() && count[0] < MAX_NCN_FILES) {
                String id = c.getString(0);
                String name = c.getString(1);
                String mime = c.getString(2);
                long size = c.isNull(3) ? 0L : c.getLong(3);
                if (name == null) continue;
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    walkTree(treeUri, id, folder + name + "/", depth + 1, count, batch);
                } else if (name.matches("(?i).*\\.(mid|midi|cur|lyr)$")) {
                    Uri fileUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id);
                    batch.put(fileMeta(fileUri, name, folder + name, size));
                    count[0]++;
                    if (batch.length() >= 100) {
                        emitBatch(batch);
                        // JSONArray is mutable; clear it only after the exact serialized batch was queued.
                        while (batch.length() > 0) batch.remove(batch.length() - 1);
                    }
                }
            }
        }
    }
    private String readableName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {}
        return uri.getLastPathSegment() == null ? "unknown.sf2" : uri.getLastPathSegment();
    }
    private long readableSize(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.SIZE}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.isNull(0)?0L:c.getLong(0);
        } catch (Exception ignored) {}
        return 0L;
    }
    private void js(String code) {
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(code, null);
        });
    }
    private void notice(String message) {
        js("if(window.toast)toast(" + JSONObject.quote(message) + ")");
    }
    @Override protected void onDestroy() {
        if (webFileCallback != null) webFileCallback.onReceiveValue(null);
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
